const { orderProducts } = require("./ORD/CREATE");
const { modifyOrder } = require("./ORD/MODIFY");
const { orderReview } = require("./ORD/REVIEW");
const { askToCheckoutOrder } = require("./ORD/CHECKOUT");
const { askToCancelOrder } = require("./ORD/CANCEL");
const { checkAvailability } = require("./INV/AVAIL");
const { answerPriceAndSales } = require("./INV/PRICE_AND_SALES");
const { answerGeneralInfo } = require("./BUS/GENERAL_INFO");

const CATEGORY_HANDLERS = {
  ORD: {
    CREATE: async (ctx) =>
      orderProducts({
        message: ctx.message,
        customer_id: ctx.customer_id,
        shop_id: ctx.shop_id,
        history: ctx.history,
        openQsCtx: ctx.openQsCtx,
        maxPerProduct: ctx.maxPerProduct,
      }),

    MODIFY: async (ctx) =>
      modifyOrder({
        message: ctx.message,
        customer_id: ctx.customer_id,
        shop_id: ctx.shop_id,
        order_id: ctx.order_id,
        activeOrder: ctx.activeOrder,
        items: ctx.items,
        history: ctx.history,
        openQsCtx: ctx.openQsCtx,
        maxPerProduct: ctx.maxPerProduct,
      }),

    REVIEW: async (ctx) =>
      orderReview(
        ctx.activeOrder,
        ctx.items,
        ctx.isEnglish,
        ctx.customer_id,
        ctx.shop_id
      ),

    CANCEL: async (ctx) =>
      askToCancelOrder(
        ctx.activeOrder,
        ctx.isEnglish,
        ctx.customer_id,
        ctx.shop_id
      ),

    CHECKOUT: async (ctx) =>
      askToCheckoutOrder(
        ctx.activeOrder,
        ctx.isEnglish,
        ctx.customer_id,
        ctx.shop_id
      ),
  },
  INV: {
    AVAIL: async (ctx) =>
      checkAvailability({
        message: ctx.message,
        customer_id: ctx.customer_id,
        shop_id: ctx.shop_id,
        history: ctx.history,
        isEnglish: ctx.isEnglish,
        maxPerProduct: ctx.maxPerProduct,
      }),

    PRICE_AND_SALES: async (ctx) =>
      answerPriceAndSales({
        message: ctx.message,
        customer_id: ctx.customer_id,
        shop_id: ctx.shop_id,
        history: ctx.history,
        isEnglish: ctx.isEnglish,
      }),
  },
  BUS: {
    GENERAL_INFO: async (ctx) =>
      answerGeneralInfo({
        message: ctx.message,
        customer_id: ctx.customer_id,
        shop_id: ctx.shop_id,
        history: ctx.history,
      }),
  },
};

const ALLOWED = Object.fromEntries(
  Object.entries(CATEGORY_HANDLERS).map(([cat, subs]) => [
    cat,
    new Set(Object.keys(subs)),
  ])
);

function isValidCategorySub(category, subcategory) {
  if (!category || !subcategory) return false;
  const cat = String(category).toUpperCase().trim();
  const sub = String(subcategory).toUpperCase().trim();
  return !!(ALLOWED[cat] && ALLOWED[cat].has(sub));
}

async function routeByCategory(category, subcategory, ctx) {
  if (!category || !subcategory) return null;

  const cat = String(category).toUpperCase().trim();
  const sub = String(subcategory).toUpperCase().trim();

  const catHandlers = CATEGORY_HANDLERS[cat];
  if (!catHandlers) return null;

  const handler = catHandlers[sub];
  if (!handler) return null;

  return handler(ctx);
}

module.exports = {
  routeByCategory,
  isValidCategorySub,
};
