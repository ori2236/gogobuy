Promotion source collision fix for 32065

Changed file:
- scripts/planLeshemPromotionsSafe.js

What it fixes:
- Detects two source promotions that target the same product or exact same product group,
  overlap in dates, but have different promotion terms.
- Marks both rows BLOCKED during planning so partial apply skips them instead of failing
  after an earlier action from the same plan has been inserted inside the transaction.

After extracting into the project root, regenerate the approved plan, preview it,
and run the partial publisher.
