const assert = require("assert");
const Module = require("module");

// The regression checks below exercise matching helpers without a live DB. The
// project ZIP intentionally does not contain node_modules, so mysql2 is stubbed
// while the module is loaded. The stub also returns no custom token weights.
const originalLoad = Module._load;
Module._load = function patchedLoad(request, parent, isMain) {
  if (request === "mysql2/promise") {
    return {
      createPool() {
        return {
          query: async () => [[], []],
          getConnection: async () => {
            throw new Error("Unexpected connection request in regression test");
          },
          end: async () => {},
        };
      },
    };
  }
  return originalLoad.call(this, request, parent, isMain);
};

const {
  tokenizeName,
  tokenSimilarity,
  filterRowsByExcludeTokens,
} = require("../utilities/tokens");
const {
  normalizeRequestTokens,
  buildTokenMatchMeta,
  tokenCoverageThreshold,
  buildBroadSearchFragments,
  pickBestWeighted,
} = require("../services/products");

Module._load = originalLoad;

async function main() {
  const productsSource = require("fs").readFileSync(
    require("path").join(__dirname, "../services/products.js"),
    "utf8",
  );
  assert(
    !productsSource.includes('debugLabel: "shopWide"') &&
      !productsSource.includes("findBestProductForRequest.return.shopWide"),
    "product matching must never fall back to an unrestricted whole-shop search",
  );

  assert.deepStrictEqual(
    tokenizeName("מגבונים ביביסיטר 9יח ללא בישום"),
    ["מגבונים", "ביביסיטר", "9", "יח", "ללא", "בישום"],
    "digit-letter packaging tokens must be split",
  );

  assert(
    tokenSimilarity("פירכיות", "פריכיות") >= 0.8,
    "adjacent-letter Hebrew spelling variants must match",
  );
  assert(
    buildBroadSearchFragments(["פירכיות"]).some((fragment) =>
      "פריכיות".includes(fragment),
    ),
    "the broad SQL pre-filter must retain transposed spelling candidates",
  );

  assert(
    tokenSimilarity("מלפפונים", "מלפפון") >= 0.8,
    "singular/plural Hebrew forms must match",
  );

  assert.deepStrictEqual(
    normalizeRequestTokens(tokenizeName("תבנית ביצים")),
    ["ביצים"],
    "egg-tray packaging wording must not be mandatory",
  );

  const requestedSalmon = tokenizeName("סלמון פרוסות ללא עור");
  const noSkinSalmon = tokenizeName("פילה סלמון מנות ללא עור רוזנרס");
  const genericSalmon = tokenizeName("פילה סלמון");
  const specificMeta = buildTokenMatchMeta(requestedSalmon, noSkinSalmon);
  const genericMeta = buildTokenMatchMeta(requestedSalmon, genericSalmon);

  assert(
    specificMeta.coverage >= tokenCoverageThreshold(requestedSalmon),
    "no-skin salmon must survive a synonym mismatch such as slices vs portions",
  );
  assert(
    specificMeta.coverage > genericMeta.coverage,
    "specific no-skin salmon must outrank a generic default salmon",
  );

  const wipesRequest = tokenizeName("מגבונים ללא בישום");
  const wipesProduct = tokenizeName("מגבונים ביביסיטר 9יח ללא בישום");
  assert.strictEqual(
    buildTokenMatchMeta(wipesRequest, wipesProduct).coverage,
    1,
    "partial product names must match when every requested property exists",
  );


  const negationAwareSalmon = filterRowsByExcludeTokens(
    [
      { id: 1, name: "פילה סלמון מנות ללא עור" },
      { id: 2, name: "פילה סלמון עם עור" },
    ],
    ["עור"],
  );
  assert.deepStrictEqual(
    negationAwareSalmon.map((row) => row.id),
    [1],
    "exclude tokens must keep a product whose name explicitly says ללא עור",
  );

  const negationAwareWipes = filterRowsByExcludeTokens(
    [
      { id: 1, name: "מגבונים ביביסיטר 9יח ללא בישום" },
      { id: 2, name: "מגבונים בניחוח פרחים עם בישום" },
    ],
    ["בישום"],
  );
  assert.deepStrictEqual(
    negationAwareWipes.map((row) => row.id),
    [1],
    "exclude tokens must keep a product whose name explicitly says ללא בישום",
  );

  const cucumber = await pickBestWeighted({
    shop_id: 2,
    rows: [
      {
        id: 35128,
        name: "מלפפון (ביכורי שדה)",
        price: 8.9,
        is_default: 1,
        is_consignment: 1,
      },
      {
        id: 35906,
        name: "מלפפון בייבי",
        price: 12.9,
        is_default: 1,
        is_consignment: 1,
      },
    ],
    reqTokens: tokenizeName("מלפפונים"),
    excludeTokens: [],
    minCoverage: 0.8,
  });
  assert.strictEqual(
    Number(cucumber.id),
    35128,
    "a generic cucumber request must prefer normal cucumber over baby cucumber",
  );

  const eggs = await pickBestWeighted({
    shop_id: 2,
    rows: [
      {
        id: 35190,
        name: "ביצים 30 יחידות L",
        price: 35.22,
        is_default: 1,
      },
      {
        id: 35361,
        name: "ביצים קינדר 3 יח' (גוילי)",
        price: 13.9,
        is_default: 0,
      },
    ],
    reqTokens: normalizeRequestTokens(tokenizeName("תבנית ביצים")),
    excludeTokens: [],
    minCoverage: 1,
  });
  assert.strictEqual(
    Number(eggs.id),
    35190,
    "an egg-tray request must prefer the real 30-unit egg tray over Kinder eggs",
  );

  const salmon = await pickBestWeighted({
    shop_id: 2,
    rows: [
      {
        id: 35444,
        name: "פילה סלמון מנות ללא עור @!(רוזנרס)",
        price: 125.9,
        is_default: 0,
      },
      {
        id: 36973,
        name: "פילה סלמון",
        price: 119.9,
        is_default: 1,
      },
    ],
    reqTokens: requestedSalmon,
    excludeTokens: [],
    minCoverage: tokenCoverageThreshold(requestedSalmon),
  });
  assert.strictEqual(
    Number(salmon.id),
    35444,
    "specific no-skin salmon must beat generic default salmon",
  );

  console.log("product matching regression checks passed");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
