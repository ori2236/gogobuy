/*
  Production-safe data hotfix for the product matching incidents reported on
  2026-08-04. Dry run is the default. Use --confirm only after reviewing output.

  It does three targeted things for one shop:
  1. Marks fresh consignment produce as shop defaults.
  2. Removes Kinder chocolate products from the real Eggs category.
  3. Makes the 30-unit egg tray the default egg product.

  Usage:
    node scripts/applyProductMatchingHotfix.js --shopId=2
    node scripts/applyProductMatchingHotfix.js --shopId=2 --confirm
*/

require("dotenv").config({ quiet: true });

const db = require("../config/db");
const { ensureProductDefaultSchemaNow } = require("../utilities/productDefaultSchema");

function getArg(name, fallback = null) {
  const prefix = `--${name}=`;
  const found = process.argv.find((arg) => arg.startsWith(prefix));
  return found ? found.slice(prefix.length) : fallback;
}

function hasFlag(name) {
  return process.argv.includes(`--${name}`);
}

function backupTableName(shopId) {
  const stamp = new Date().toISOString().replace(/[-:TZ.]/g, "").slice(0, 14);
  return `bak_product_match_hotfix_s${shopId}_${stamp}`;
}

async function selectRows(conn, shopId) {
  const [produce] = await conn.query(
    `
      SELECT id, name, category, sub_category, is_default, is_consignment, stock_amount
      FROM product
      WHERE shop_id = ?
        AND COALESCE(is_consignment,0) = 1
        AND category = 'Produce'
      ORDER BY sub_category, name, id
    `,
    [shopId],
  );

  const [eggCategory] = await conn.query(
    `
      SELECT id, name, category, sub_category, is_default, is_consignment, stock_amount
      FROM product
      WHERE shop_id = ?
        AND category = 'Dairy & Eggs'
        AND sub_category = 'Eggs'
      ORDER BY name, id
    `,
    [shopId],
  );

  const [kinderInEggs] = await conn.query(
    `
      SELECT id, name, category, sub_category, is_default, is_consignment, stock_amount
      FROM product
      WHERE shop_id = ?
        AND category = 'Dairy & Eggs'
        AND sub_category = 'Eggs'
        AND name COLLATE utf8mb4_general_ci LIKE '%קינדר%'
      ORDER BY id
    `,
    [shopId],
  );

  const eggName = String(getArg("eggName", "ביצים 30 יחידות L")).trim();
  let [eggTargets] = await conn.query(
    `
      SELECT id, name, category, sub_category, is_default, is_consignment, stock_amount
      FROM product
      WHERE shop_id = ?
        AND name COLLATE utf8mb4_general_ci = ?
      ORDER BY stock_amount DESC, id DESC
    `,
    [shopId, eggName],
  );

  if (!eggTargets.length) {
    [eggTargets] = await conn.query(
      `
        SELECT id, name, category, sub_category, is_default, is_consignment, stock_amount
        FROM product
        WHERE shop_id = ?
          AND category = 'Dairy & Eggs'
          AND sub_category = 'Eggs'
          AND name COLLATE utf8mb4_general_ci LIKE 'ביצים%30%L%'
        ORDER BY stock_amount DESC, id DESC
      `,
      [shopId],
    );
  }

  return {
    produce: produce || [],
    eggCategory: eggCategory || [],
    kinderInEggs: kinderInEggs || [],
    eggTargets: eggTargets || [],
  };
}

function printPreview(shopId, rows) {
  const selectedTarget = rows.eggTargets[0] || null;
  console.log(JSON.stringify({
    mode: hasFlag("confirm") ? "confirm" : "dry-run",
    shop_id: shopId,
    produce_consignment_total: rows.produce.length,
    produce_defaults_to_enable: rows.produce.filter((row) => Number(row.is_default || 0) !== 1).length,
    egg_category_total: rows.eggCategory.length,
    kinder_rows_to_reclassify: rows.kinderInEggs,
    requested_egg_default: selectedTarget,
    additional_egg_target_candidates: rows.eggTargets.slice(1),
  }, null, 2));
}

async function main() {
  const shopId = Number(getArg("shopId", 2));
  if (!Number.isInteger(shopId) || shopId <= 0) {
    throw new Error("--shopId must be a positive integer");
  }

  const confirm = hasFlag("confirm");
  const conn = await db.getConnection();

  try {
    await ensureProductDefaultSchemaNow(conn);
    const rows = await selectRows(conn, shopId);
    printPreview(shopId, rows);

    if (!rows.eggTargets.length) {
      throw new Error(
        "Could not find the requested 30-unit egg tray. No changes were made. Pass --eggName=... if its production name differs.",
      );
    }

    if (!confirm) {
      console.log("[product-match-hotfix] dry run only. Re-run with --confirm to apply.");
      return;
    }

    const targetEgg = rows.eggTargets[0];
    const backup = backupTableName(shopId);
    if (!/^bak_product_match_hotfix_s\d+_\d{14}$/.test(backup)) {
      throw new Error("Invalid generated backup table name");
    }

    await conn.query(`CREATE TABLE \`${backup}\` LIKE product`);
    const [backupResult] = await conn.query(
      `
        INSERT INTO \`${backup}\`
        SELECT *
        FROM product
        WHERE shop_id = ?
          AND (
            (COALESCE(is_consignment,0) = 1 AND category = 'Produce')
            OR (category = 'Dairy & Eggs' AND sub_category = 'Eggs')
            OR name COLLATE utf8mb4_general_ci LIKE '%קינדר%'
          )
      `,
      [shopId],
    );

    await conn.beginTransaction();
    try {
      const [produceResult] = await conn.query(
        `
          UPDATE product
          SET is_default = 1
          WHERE shop_id = ?
            AND COALESCE(is_consignment,0) = 1
            AND category = 'Produce'
        `,
        [shopId],
      );

      const [kinderResult] = await conn.query(
        `
          UPDATE product
          SET category = 'Snacks',
              sub_category = 'Candy & Chocolate',
              is_default = 0,
              emoji = '🍫'
          WHERE shop_id = ?
            AND category = 'Dairy & Eggs'
            AND sub_category = 'Eggs'
            AND name COLLATE utf8mb4_general_ci LIKE '%קינדר%'
        `,
        [shopId],
      );

      const [clearEggDefaultsResult] = await conn.query(
        `
          UPDATE product
          SET is_default = 0
          WHERE shop_id = ?
            AND category = 'Dairy & Eggs'
            AND sub_category = 'Eggs'
        `,
        [shopId],
      );

      const [eggDefaultResult] = await conn.query(
        `
          UPDATE product
          SET is_default = 1
          WHERE shop_id = ?
            AND id = ?
            AND category = 'Dairy & Eggs'
            AND sub_category = 'Eggs'
          LIMIT 1
        `,
        [shopId, targetEgg.id],
      );

      if (Number(eggDefaultResult.affectedRows || 0) !== 1) {
        throw new Error(`Failed to set product ${targetEgg.id} as the egg default`);
      }

      await conn.commit();

      const verified = await selectRows(conn, shopId);
      console.log(JSON.stringify({
        applied: true,
        shop_id: shopId,
        backup_table: backup,
        backed_up_rows: Number(backupResult.affectedRows || 0),
        produce_rows_touched: Number(produceResult.affectedRows || 0),
        kinder_rows_reclassified: Number(kinderResult.affectedRows || 0),
        egg_rows_cleared: Number(clearEggDefaultsResult.affectedRows || 0),
        egg_default_rows_set: Number(eggDefaultResult.affectedRows || 0),
        verified_egg_default: verified.eggCategory.filter((row) => Number(row.is_default || 0) === 1),
        remaining_kinder_in_egg_category: verified.kinderInEggs,
        produce_defaults_enabled: verified.produce.filter((row) => Number(row.is_default || 0) === 1).length,
      }, null, 2));
    } catch (error) {
      await conn.rollback();
      throw error;
    }
  } finally {
    conn.release();
  }
}

main()
  .catch((error) => {
    console.error("[product-match-hotfix] failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    try {
      await db.end();
    } catch {}
  });
