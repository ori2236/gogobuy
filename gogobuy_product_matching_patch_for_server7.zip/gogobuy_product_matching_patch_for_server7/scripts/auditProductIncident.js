/*
  Find a reported product-matching incident in the live production database.

  The chat table is automatically cleaned after roughly 96 hours, so run this
  as soon as possible after a report.

  Examples:
    node scripts/auditProductIncident.js --shopId=2 --term=פתיתים --term=כוכבים
    node scripts/auditProductIncident.js --shopId=2 --term=מלפפון --hours=48
    node scripts/auditProductIncident.js --shopId=2 --term=פתיתים --term=כוכבים --from=2026-08-04T00:00:00 --to=2026-08-05T00:00:00
*/

require("dotenv").config({ quiet: true });

const fs = require("fs");
const path = require("path");
const db = require("../config/db");

function getArg(name, fallback = null) {
  const prefix = `--${name}=`;
  const found = process.argv.find((arg) => arg.startsWith(prefix));
  return found ? found.slice(prefix.length) : fallback;
}

function getAllArgs(name) {
  const prefix = `--${name}=`;
  return process.argv
    .filter((arg) => arg.startsWith(prefix))
    .map((arg) => arg.slice(prefix.length).trim())
    .filter(Boolean);
}

function parseDate(value, label) {
  if (!value) return null;
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) {
    throw new Error(`Invalid --${label} date: ${value}`);
  }
  return parsed;
}

function safeFileTimestamp() {
  return new Date().toISOString().replace(/[-:TZ.]/g, "").slice(0, 14);
}

function compactMessage(row) {
  return {
    id: Number(row.id),
    sender: row.sender,
    status: row.status,
    message: row.message,
    created_at: row.created_at,
  };
}

async function findMatchingMessages({ shopId, terms, from, to }) {
  let sql = `
    SELECT
      ch.id,
      ch.customer_id,
      ch.shop_id,
      ch.message,
      ch.sender,
      ch.status,
      ch.created_at,
      c.name AS customer_name,
      c.phone AS customer_phone
    FROM chat ch
    JOIN customer c ON c.id = ch.customer_id
    WHERE ch.shop_id = ?
      AND ch.sender = 'customer'
      AND ch.created_at >= ?
      AND ch.created_at <= ?
  `;
  const params = [shopId, from, to];

  for (const term of terms) {
    sql += ` AND ch.message COLLATE utf8mb4_general_ci LIKE CONCAT('%', ?, '%')`;
    params.push(term);
  }

  sql += ` ORDER BY ch.created_at ASC, ch.id ASC`;
  const [rows] = await db.query(sql, params);
  return rows || [];
}

async function fetchChatContext(hit) {
  const hitTime = new Date(hit.created_at);
  const from = new Date(hitTime.getTime() - 20 * 60 * 1000);
  const to = new Date(hitTime.getTime() + 45 * 60 * 1000);

  const [rows] = await db.query(
    `
      SELECT id, sender, status, message, created_at
      FROM chat
      WHERE shop_id = ?
        AND customer_id = ?
        AND created_at BETWEEN ? AND ?
      ORDER BY created_at ASC, id ASC
    `,
    [hit.shop_id, hit.customer_id, from, to],
  );

  return (rows || []).map(compactMessage);
}

async function fetchRelevantOrders(hit) {
  const hitTime = new Date(hit.created_at);
  const from = new Date(hitTime.getTime() - 60 * 60 * 1000);
  const to = new Date(hitTime.getTime() + 4 * 60 * 60 * 1000);

  const [rows] = await db.query(
    `
      SELECT
        o.id AS order_id,
        o.status AS order_status,
        o.price AS order_total,
        o.created_at AS order_created_at,
        o.updated_at AS order_updated_at,
        oi.id AS order_item_id,
        oi.created_at AS item_added_at,
        oi.product_id,
        p.name AS matched_product_name,
        oi.amount,
        oi.requested_units,
        oi.price AS item_price
      FROM orders o
      LEFT JOIN order_item oi ON oi.order_id = o.id
      LEFT JOIN product p ON p.id = oi.product_id
      WHERE o.shop_id = ?
        AND o.customer_id = ?
        AND (
          oi.created_at BETWEEN ? AND ?
          OR (
            o.created_at <= ?
            AND o.updated_at >= ?
          )
        )
      ORDER BY o.created_at ASC, o.id ASC, oi.created_at ASC, oi.id ASC
    `,
    [hit.shop_id, hit.customer_id, from, to, to, from],
  );

  const byOrder = new Map();
  for (const row of rows || []) {
    const orderId = Number(row.order_id);
    if (!byOrder.has(orderId)) {
      byOrder.set(orderId, {
        order_id: orderId,
        status: row.order_status,
        total: row.order_total === null ? null : Number(row.order_total),
        created_at: row.order_created_at,
        updated_at: row.order_updated_at,
        items: [],
      });
    }

    if (row.order_item_id !== null && row.order_item_id !== undefined) {
      byOrder.get(orderId).items.push({
        order_item_id: Number(row.order_item_id),
        item_added_at: row.item_added_at,
        product_id: Number(row.product_id),
        matched_product_name: row.matched_product_name,
        amount: row.amount === null ? null : Number(row.amount),
        requested_units:
          row.requested_units === null ? null : Number(row.requested_units),
        item_price: row.item_price === null ? null : Number(row.item_price),
      });
    }
  }

  return Array.from(byOrder.values());
}

async function main() {
  const shopId = Number(getArg("shopId", 2));
  if (!Number.isInteger(shopId) || shopId <= 0) {
    throw new Error("--shopId must be a positive integer");
  }

  const terms = getAllArgs("term");
  if (!terms.length) {
    throw new Error("Pass at least one search term, for example --term=פתיתים --term=כוכבים");
  }

  const hours = Math.max(1, Math.min(720, Number(getArg("hours", 96)) || 96));
  const explicitFrom = parseDate(getArg("from"), "from");
  const explicitTo = parseDate(getArg("to"), "to");
  const to = explicitTo || new Date();
  const from = explicitFrom || new Date(to.getTime() - hours * 60 * 60 * 1000);

  if (from > to) throw new Error("--from must be earlier than --to");

  console.log("[product-incident-audit] searching", {
    shop_id: shopId,
    terms,
    from: from.toISOString(),
    to: to.toISOString(),
  });

  const hits = await findMatchingMessages({ shopId, terms, from, to });
  const incidents = [];

  for (const hit of hits) {
    incidents.push({
      matching_message: {
        id: Number(hit.id),
        customer_id: Number(hit.customer_id),
        customer_name: hit.customer_name,
        customer_phone: hit.customer_phone,
        message: hit.message,
        created_at: hit.created_at,
      },
      chat_context: await fetchChatContext(hit),
      relevant_orders: await fetchRelevantOrders(hit),
    });
  }

  const report = {
    generated_at: new Date().toISOString(),
    shop_id: shopId,
    terms,
    from: from.toISOString(),
    to: to.toISOString(),
    matched_messages: hits.length,
    incidents,
  };

  const reportsDir = path.resolve(__dirname, "..", "reports");
  fs.mkdirSync(reportsDir, { recursive: true });
  const reportPath = path.join(
    reportsDir,
    `product_incident_audit_shop${shopId}_${safeFileTimestamp()}.json`,
  );
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2), "utf8");

  if (!incidents.length) {
    console.log("[product-incident-audit] no matching customer messages were found.");
    console.log("The chat table is cleaned after about 96 hours. Also check PM2/CloudWatch logs for [ORD-CREATE].");
  } else {
    console.table(
      incidents.map((incident) => ({
        customer_id: incident.matching_message.customer_id,
        customer_name: incident.matching_message.customer_name,
        customer_phone: incident.matching_message.customer_phone,
        message: incident.matching_message.message,
        created_at: incident.matching_message.created_at,
        relevant_orders: incident.relevant_orders.length,
        matched_products: incident.relevant_orders
          .flatMap((order) => order.items)
          .map((item) => item.matched_product_name)
          .filter(Boolean)
          .join(" | "),
      })),
    );
  }

  console.log(`[product-incident-audit] report: ${reportPath}`);
}

main()
  .catch((error) => {
    console.error("[product-incident-audit] failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    try {
      await db.end();
    } catch {}
  });
