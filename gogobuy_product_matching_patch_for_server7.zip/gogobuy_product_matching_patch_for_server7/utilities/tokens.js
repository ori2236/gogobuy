function normalizeToken(t) {
  return (
    String(t || "")
      .normalize("NFKC")
      .replace(/[\u0591-\u05C7]/g, "")
      .replace(/['’"`\u05F3\u05F4]/g, "")
      .trim()
  );
}

function normForContains(s) {
  return normalizeToken(String(s || "").toLowerCase());
}

const NEGATION_PREFIXES = new Set([
  "ללא",
  "בלי",
  "נטול",
  "נטולת",
  "נטולי",
  "נטולות",
  "without",
  "free",
  "freefrom",
  "no",
]);

function containsPositiveExcludedToken(value, excludedToken) {
  const text = normForContains(value);
  const excluded = normForContains(excludedToken);
  if (!text || !excluded || !text.includes(excluded)) return false;

  const tokens = tokenizeName(text);
  for (let i = 0; i < tokens.length; i += 1) {
    const token = tokens[i];
    if (token !== excluded && !token.includes(excluded)) continue;

    const previous = i > 0 ? tokens[i - 1] : "";
    const twoBack = i > 1 ? tokens[i - 2] : "";
    const negated = NEGATION_PREFIXES.has(previous) ||
      (previous === "from" && NEGATION_PREFIXES.has(twoBack));

    if (!negated) return true;
  }

  // If tokenization did not preserve the occurrence, fall back to phrase checks.
  const safePhrases = [
    `ללא ${excluded}`,
    `בלי ${excluded}`,
    `נטול ${excluded}`,
    `נטולת ${excluded}`,
    `without ${excluded}`,
    `${excluded} free`,
    `free from ${excluded}`,
    `no ${excluded}`,
  ];
  return !safePhrases.some((phrase) => text.includes(phrase));
}

function filterRowsByExcludeTokens(rows, excludeTokens) {
  if (!rows || !rows.length || !excludeTokens.length) return rows || [];

  const ex = excludeTokens.map(normForContains).filter(Boolean);

  return rows.filter((r) => {
    const fields = [r.name || "", r.display_name_en || ""];
    return !ex.some((token) =>
      fields.some((field) => containsPositiveExcludedToken(field, token)),
    );
  });
}

const HEBREW_NOISE_TOKENS = new Set([
  "רגיל",
  "רגילה",
  "רגילים",
  "רגילות",
  "קטן",
  "קטנה",
  "קטנים",
  "קטנות",
  "גדול",
  "גדולה",
  "גדולים",
  "גדולות",
]);

const ENGLISH_NOISE_TOKENS = new Set([
  "regular",
  "normal",
  "plain",
  "classic",
  "small",
  "large",
  "big",
]);

function isNoiseToken(t) {
  return HEBREW_NOISE_TOKENS.has(t) || ENGLISH_NOISE_TOKENS.has(t);
}

function tokenImportance(token) {
  const t = String(token || "").toLowerCase();

  if (/^\d+(\.\d+)?$/.test(t)) return 0.5;

  if (/\d/.test(t)) return 0.7;

  return 1;
}

function tokenizeName(str) {
  if (!str) return [];

  const baseTokens = String(str)
    .toLowerCase()
    .normalize("NFKC")
    .replace(/([0-9])([a-z\u0590-\u05FF])/gi, "$1 $2")
    .replace(/([a-z\u0590-\u05FF])([0-9])/gi, "$1 $2")
    .replace(/[^\w\u0590-\u05FF]+/g, " ")
    .split(/\s+/)
    .map((t) => normalizeToken(t))
    .filter(Boolean);

  if (baseTokens.length <= 1) return baseTokens;

  const filtered = baseTokens.filter((t) => !isNoiseToken(t));
  return filtered.length ? filtered : baseTokens;
}

const FINAL_HEBREW_LETTERS = Object.freeze({
  ך: "כ",
  ם: "מ",
  ן: "נ",
  ף: "פ",
  ץ: "צ",
});

function normalizeTokenForSimilarity(value) {
  return normalizeToken(String(value || "").toLowerCase())
    .replace(/[ךםןףץ]/g, (ch) => FINAL_HEBREW_LETTERS[ch] || ch)
    .replace(/(.)\1{2,}/g, "$1$1");
}

function isHebrewToken(value) {
  return /^[\u0590-\u05FF]+$/.test(value);
}

function stripHebrewPluralSuffix(value) {
  if (!isHebrewToken(value) || value.length < 5) return value;
  if (value.endsWith("ימ") || value.endsWith("ות")) return value.slice(0, -2);
  return value;
}

function stripHebrewMatres(value) {
  if (!isHebrewToken(value) || value.length < 5) return value;
  return value.replace(/[יו]/g, "");
}

// Optimal string alignment distance. Unlike classic Levenshtein, this treats
// one adjacent letter swap as one edit, which is common in Hebrew typing
// mistakes such as "פירכיות" vs "פריכיות".
function damerauLevenshtein(a, b) {
  const s = String(a || "");
  const t = String(b || "");
  if (s === t) return 0;
  if (!s) return t.length;
  if (!t) return s.length;

  const matrix = Array.from({ length: s.length + 1 }, () =>
    new Array(t.length + 1).fill(0),
  );

  for (let i = 0; i <= s.length; i += 1) matrix[i][0] = i;
  for (let j = 0; j <= t.length; j += 1) matrix[0][j] = j;

  for (let i = 1; i <= s.length; i += 1) {
    for (let j = 1; j <= t.length; j += 1) {
      const cost = s[i - 1] === t[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost,
      );

      if (
        i > 1 &&
        j > 1 &&
        s[i - 1] === t[j - 2] &&
        s[i - 2] === t[j - 1]
      ) {
        matrix[i][j] = Math.min(matrix[i][j], matrix[i - 2][j - 2] + 1);
      }
    }
  }

  return matrix[s.length][t.length];
}

function tokenSimilarity(a, b) {
  const left = normalizeTokenForSimilarity(a);
  const right = normalizeTokenForSimilarity(b);
  if (!left || !right) return 0;
  if (left === right) return 1;

  const leftStem = stripHebrewPluralSuffix(left);
  const rightStem = stripHebrewPluralSuffix(right);
  if (leftStem === rightStem && leftStem.length >= 3) return 0.96;

  const leftBare = stripHebrewMatres(leftStem);
  const rightBare = stripHebrewMatres(rightStem);
  if (leftBare === rightBare && leftBare.length >= 3) return 0.9;

  const maxLen = Math.max(left.length, right.length);
  const minLen = Math.min(left.length, right.length);
  if (minLen < 3) return 0;

  const distance = damerauLevenshtein(left, right);
  if (distance === 1 && maxLen >= 4) return Math.max(0.82, 1 - distance / maxLen);

  const sameEdges = left[0] === right[0] && left[left.length - 1] === right[right.length - 1];
  if (distance === 2 && maxLen >= 7 && sameEdges) {
    return Math.max(0.76, 1 - distance / maxLen);
  }

  return Math.max(0, 1 - distance / maxLen);
}

function getExcludeTokensFromReq(req) {
  const raw = req && req.exclude_tokens;
  if (!Array.isArray(raw)) return [];
  return raw
    .map((x) => normalizeToken(typeof x === "string" ? x : String(x || "")))
    .map((x) => x.toLowerCase())
    .filter(Boolean);
}

module.exports = {
  tokenImportance,
  tokenizeName,
  tokenSimilarity,
  damerauLevenshtein,
  normalizeTokenForSimilarity,
  containsPositiveExcludedToken,
  getExcludeTokensFromReq,
  filterRowsByExcludeTokens,
};
