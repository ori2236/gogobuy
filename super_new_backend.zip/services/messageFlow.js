const {
  routeByCategory,
  isValidCategorySub,
} = require("../categoryHandlers/router");
const { classifyIncoming } = require("../services/classifier");
const { wasSentBefore, saveChat } = require("../repositories/chat");
const { ensureCustomer } = require("../repositories/customer");
const {
  fetchOpenQuestions,
  fetchRecentClosedQuestions,
  buildOpenQuestionsContextForPrompt,
} = require("../utilities/openQuestions");
const { normalizeOutboundMessage } = require("../utilities/normalize");
const {
  getActiveOrder,
  getOrderItems,
  buildActiveOrderSignals,
} = require("../utilities/orders");
const { detectIsEnglish } = require("../utilities/lang");
const { checkIfToCancelOrder } = require("../categoryHandlers/ORD/CANCEL");
const { checkIfToCheckoutOrder } = require("../categoryHandlers/ORD/CHECKOUT");
const { answerOrderStatus } = require("../categoryHandlers/ORD/STATUS");
const { sendWhatsAppMarkAsRead } = require("../utilities/whatsapp");
const { startSlowProgression } = require("./sendProgressionMessage");
const { handleSuggestionReply } = require("./orderSuggestions");
const { handleFulfillmentReply } = require("./fulfillment");
const {
  handleCheckoutNudgeReply,
  attachCheckoutNudgeIfNeeded,
} = require("../utilities/checkoutNudge");

const maxPerProduct = 10;

function isOrderStatusQuestion(message) {
  const raw = String(message || "").trim().toLowerCase();
  if (!raw) return false;

  const asksCartContent = /(מה\s+יש\s+(בסל|בעגלה|בהזמנה)|תראה\s+לי\s+(את\s+)?(הסל|העגלה)|סיכום\s+הזמנה|cart|basket|order summary)/i.test(raw);
  if (asksCartContent) return false;

  return /(מה\s+עם\s+ההזמנה|איפה\s+ההזמנה|סטטוס\s+הזמנה|מה\s+קורה\s+עם\s+ההזמנה|המשלוח\s+יצא|שליח\s+בדרך|ההזמנה\s+מוכנה|מתי\s+מגיע|מתי\s+מוכן|נשלחה|נאספה|status|tracking|where\s+is\s+my\s+order|is\s+my\s+order\s+ready|delivery\s+sent)/i.test(raw);
}

async function processMessage(
  message,
  phone_number,
  shop_id,
  waMessageId = "",
  receivedAt = Date.now(),
  businessPhoneNumberId = "",
) {
  const customer_id = await ensureCustomer(shop_id, phone_number);

  const wasSent = await wasSentBefore(customer_id, shop_id, message);
  if (wasSent) {
    return { skipSend: true };
  }

  if (waMessageId) {
    setTimeout(() => {
      sendWhatsAppMarkAsRead(waMessageId, businessPhoneNumberId).catch((e) =>
        console.error("[wa markAsRead]", e?.response?.data || e),
      );
    }, 800);
  }

  const activeOrder = await getActiveOrder(customer_id, shop_id);
  const order_id = activeOrder ? activeOrder.id : null;
  const items = activeOrder ? await getOrderItems(activeOrder.id) : [];
  const sig = buildActiveOrderSignals(activeOrder, items);
  const openQs = await fetchOpenQuestions(customer_id, shop_id, 20);

  const fulfillmentReply = await handleFulfillmentReply({
    message,
    customer_id,
    shop_id,
    activeOrder,
    openQs,
    saveChat,
  });

  if (fulfillmentReply) return fulfillmentReply;

  const checkoutReply = await checkIfToCheckoutOrder({
    activeOrder,
    message,
    customer_id,
    shop_id,
    saveChat,
  });

  if (checkoutReply) return checkoutReply;

  const cancelReply = await checkIfToCancelOrder({
    activeOrder,
    message,
    customer_id,
    shop_id,
    saveChat,
  });

  if (cancelReply) return cancelReply;

  const checkoutNudgeReply = await handleCheckoutNudgeReply({
    message,
    customer_id,
    shop_id,
    activeOrder,
    openQs,
    saveChat,
  });

  if (checkoutNudgeReply) return checkoutNudgeReply;

  const suggestionReply = await handleSuggestionReply({
    message,
    customer_id,
    shop_id,
    activeOrder,
    openQs,
    maxPerProduct,
  });

  if (suggestionReply) {
    await saveChat({
      customer_id,
      shop_id,
      sender: "customer",
      status: "classified",
      message,
    });

    await saveChat({
      customer_id,
      shop_id,
      sender: "bot",
      status: "classified",
      message: suggestionReply,
    });

    return suggestionReply;
  }

  if (isOrderStatusQuestion(message)) {
    const statusReply = await answerOrderStatus({
      message,
      customer_id,
      shop_id,
      isEnglish: detectIsEnglish(message),
    });

    await saveChat({
      customer_id,
      shop_id,
      sender: "customer",
      status: "classified",
      message,
    });

    await saveChat({
      customer_id,
      shop_id,
      sender: "bot",
      status: "classified",
      message: statusReply,
    });

    return statusReply;
  }

  const closedQs = await fetchRecentClosedQuestions(customer_id, shop_id, 5);

  const { parsed, replyText, history } = await classifyIncoming({
    message,
    customer_id,
    shop_id,
    sig,
    openQs,
    closedQs,
  });

  if (parsed.type === "clarify") {
    await saveChat({
      customer_id,
      shop_id,
      sender: "customer",
      status: "unclassified",
      message,
    });

    //bot's question
    await saveChat({
      customer_id,
      shop_id,
      sender: "bot",
      status: "unclassified",
      message: parsed.text,
    });
    return parsed.text || "לא התקבלה תשובה מהמודל.";
  } else if (parsed.type === "classified") {
    const { category, subcategory } = parsed;
    console.log(
      `[classification] category=${category}, subcategory=${subcategory}`,
    );

    if (!isValidCategorySub(category, subcategory)) {
      const apology =
        "מצטערים, לא הצלחנו להבין את הבקשה. נשמח אם תנוסח שוב בקצרה";
      await saveChat({
        customer_id,
        shop_id,
        sender: "customer",
        status: "unclassified",
        message,
      });

      await saveChat({
        customer_id,
        shop_id,
        sender: "bot",
        status: "unclassified",
        message: apology,
      });
      return apology;
    }

    await saveChat({
      customer_id,
      shop_id,
      sender: "customer",
      status: "classified",
      message,
    });

    const openQsCtx = buildOpenQuestionsContextForPrompt(openQs);
    const isEnglish = detectIsEnglish(message);
    const ctx = {
      message,
      customer_id,
      shop_id,
      history,
      openQsCtx,
      activeOrder,
      order_id,
      items,
      isEnglish,
      maxPerProduct,
    };

    const stopProgression = startSlowProgression({
      category,
      subcategory,
      isEnglish,
      phone_number,
      waMessageId,
      receivedAt,
      typingAtMs: 2000,
      progressEveryMs: 8000,
      businessPhoneNumberId,
    });

    let botPayload = null;

    try {
      botPayload = await routeByCategory(category, subcategory, ctx);
    } catch (err) {
      console.error("[routeByCategory error]", err);
    } finally {
      stopProgression();
    }

    if (botPayload == null) {
      await saveChat({
        customer_id,
        shop_id,
        sender: "server",
        status: "close",
        message: "",
      });

      const fallback = "כרגע אין לנו תמיכה בבקשות מסוג זה";
      return fallback;
    }

    botPayload = await attachCheckoutNudgeIfNeeded({
      botPayload,
      category,
      subcategory,
      customer_id,
      shop_id,
      isEnglish,
    });

    const botText = normalizeOutboundMessage(botPayload);
    await saveChat({
      customer_id,
      shop_id,
      sender: "bot",
      status: "classified",
      message: botText,
    });

    if (botPayload && Array.isArray(botPayload.followUpMessages)) {
      for (const followUp of botPayload.followUpMessages) {
        const msg = typeof followUp === "string" ? followUp.trim() : "";
        if (!msg) continue;
        await saveChat({
          customer_id,
          shop_id,
          sender: "bot",
          status: "classified",
          message: msg,
        });
      }
    }

    return botPayload;
  } else {
    //if not classified and not clarify
    await saveChat({
      customer_id,
      shop_id,
      sender: "customer",
      status: "unclassified",
      message,
    });
    await saveChat({
      customer_id,
      shop_id,
      sender: "bot",
      status: "unclassified",
      message: replyText || "",
    });
    return replyText || "לא התקבלה תשובה מהמודל.";
  }
}

module.exports = {
  processMessage,
};
