require("dotenv").config();
const db = require("../config/db");

const SOURCE_SHOP_ID = Number(process.env.SOURCE_SHOP_ID || 2);
const TARGET_SHOP_IDS = String(process.env.TARGET_SHOP_IDS || "3,4,5")
  .split(",")
  .map((x) => Number(x.trim()))
  .filter((x) => Number.isInteger(x) && x > 0);
const FORCE = String(process.env.FORCE || "").toLowerCase() === "true";

const OPTIONAL_COLUMNS = [
  "display_name_en",
  "category",
  "sub_category",
  "description",
  "image",
  "barcode",
  "chain_product_key",
  "emoji",
];

async function getProductColumns() {
  const [rows] = await db.query(
    `SELECT COLUMN_NAME
       FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'product'`,
  );
  return new Set(rows.map((r) => r.COLUMN_NAME));
}

function col(name) {
  return `\`${name}\``;
}

async function main() {
  if (!Number.isInteger(SOURCE_SHOP_ID) || SOURCE_SHOP_ID <= 0) {
    throw new Error("SOURCE_SHOP_ID must be a positive integer");
  }
  if (!TARGET_SHOP_IDS.length) {
    throw new Error("TARGET_SHOP_IDS must include at least one target shop id");
  }
  if (TARGET_SHOP_IDS.includes(SOURCE_SHOP_ID)) {
    throw new Error("TARGET_SHOP_IDS must not include SOURCE_SHOP_ID");
  }

  const columns = await getProductColumns();
  if (!columns.has("chain_product_key")) {
    throw new Error("product.chain_product_key is missing. Run the DB preparation SQL first.");
  }

  const [sourceCountRows] = await db.query(
    `SELECT COUNT(*) AS count FROM product WHERE shop_id = ?`,
    [SOURCE_SHOP_ID],
  );
  const sourceCount = Number(sourceCountRows[0]?.count || 0);
  if (!sourceCount) {
    throw new Error(`No products found in source shop_id=${SOURCE_SHOP_ID}`);
  }

  const [targetOrders] = await db.query(
    `SELECT shop_id, COUNT(*) AS orders_count
       FROM orders
      WHERE shop_id IN (?)
      GROUP BY shop_id`,
    [TARGET_SHOP_IDS],
  );

  if (targetOrders.length && !FORCE) {
    console.error("Target shops already have orders. Refusing to delete target products.");
    console.error(targetOrders);
    console.error("If this is intentional, run with FORCE=true.");
    process.exitCode = 1;
    return;
  }

  const insertColumns = ["shop_id", "name", ...OPTIONAL_COLUMNS.filter((c) => columns.has(c)), "price", "stock_amount"];
  const selectColumns = insertColumns.map((c) => {
    if (c === "shop_id") return "? AS `shop_id`";
    if (c === "stock_amount") return "0.000 AS `stock_amount`";
    return col(c);
  });

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    if (columns.has("barcode")) {
      await conn.query(
        `UPDATE product
            SET chain_product_key = CASE
              WHEN barcode IS NOT NULL AND TRIM(barcode) <> '' THEN CONCAT('barcode:', TRIM(barcode))
              WHEN chain_product_key IS NOT NULL AND TRIM(chain_product_key) <> '' THEN chain_product_key
              ELSE CONCAT('shop', shop_id, '-product:', id)
            END
          WHERE shop_id = ?
            AND (chain_product_key IS NULL OR TRIM(chain_product_key) = '')`,
        [SOURCE_SHOP_ID],
      );
    } else {
      await conn.query(
        `UPDATE product
            SET chain_product_key = CASE
              WHEN chain_product_key IS NOT NULL AND TRIM(chain_product_key) <> '' THEN chain_product_key
              ELSE CONCAT('shop', shop_id, '-product:', id)
            END
          WHERE shop_id = ?
            AND (chain_product_key IS NULL OR TRIM(chain_product_key) = '')`,
        [SOURCE_SHOP_ID],
      );
    }

    await conn.query(`DELETE FROM product WHERE shop_id IN (?)`, [TARGET_SHOP_IDS]);

    for (const targetShopId of TARGET_SHOP_IDS) {
      const sql = `
        INSERT INTO product (${insertColumns.map(col).join(", ")})
        SELECT ${selectColumns.join(", ")}
          FROM product
         WHERE shop_id = ?`;
      await conn.query(sql, [targetShopId, SOURCE_SHOP_ID]);
    }

    await conn.commit();

    const [counts] = await db.query(
      `SELECT shop_id,
              COUNT(*) AS products_count,
              SUM(stock_amount > 0) AS products_with_positive_stock,
              SUM(stock_amount = 0) AS products_with_zero_stock
         FROM product
        WHERE shop_id IN (?)
        GROUP BY shop_id
        ORDER BY shop_id`,
      [[SOURCE_SHOP_ID, ...TARGET_SHOP_IDS]],
    );

    const [missingCopies] = await db.query(
      `SELECT chain_product_key,
              COUNT(*) AS copies_count,
              GROUP_CONCAT(shop_id ORDER BY shop_id) AS shops
         FROM product
        WHERE shop_id IN (?)
          AND chain_product_key IS NOT NULL
          AND TRIM(chain_product_key) <> ''
        GROUP BY chain_product_key
       HAVING COUNT(*) <> ?
        ORDER BY copies_count DESC
        LIMIT 50`,
      [[SOURCE_SHOP_ID, ...TARGET_SHOP_IDS], 1 + TARGET_SHOP_IDS.length],
    );

    console.log("Clone completed successfully.");
    console.table(counts);
    if (missingCopies.length) {
      console.log("Products not copied to every branch:");
      console.table(missingCopies);
    } else {
      console.log("Every chain_product_key exists in all source/target shops.");
    }
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
    await db.end();
  }
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
