const { processMessage } = require("../services/messageFlow");
const { normalizeOutboundMessage } = require("../utilities/normalize");
const { requireValidShop } = require("../repositories/shop");

async function handleMessage(req, res, next) {
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  const phoneNumber = String(req.body?.phone_number || "").trim();
  const shopIdRaw = req.body?.shop_id;

  if (!message || !phoneNumber || shopIdRaw === undefined || shopIdRaw === null || shopIdRaw === "") {
    return res.status(400).json({
      success: false,
      message: "message, phone_number and shop_id are required",
    });
  }

  try {
    const shop = await requireValidShop(shopIdRaw);

    const responseMessage = await processMessage(
      message,
      phoneNumber,
      shop.id,
    );

    if (responseMessage && responseMessage.skipSend) {
      return res.json({ success: true, message: null, skipSend: true });
    }

    const messageText = normalizeOutboundMessage(responseMessage);
    return res.json({
      success: true,
      shop_id: shop.id,
      chain_id: shop.chain_id,
      shop_name: shop.name,
      message: messageText,
    });
  } catch (error) {
    if (error?.statusCode) {
      return res.status(error.statusCode).json({
        success: false,
        message: error.publicMessage || error.message,
      });
    }

    console.error(error);
    return next(error);
  }
}

module.exports = {
  handleMessage,
};
